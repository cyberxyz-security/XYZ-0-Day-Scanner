"""
XYZ Vulnerability Scanner CLI Package
"""

__version__ = "1.0.0"
__author__ = "XYZ Security Team"
__email__ = "support@xyz-security.com"
